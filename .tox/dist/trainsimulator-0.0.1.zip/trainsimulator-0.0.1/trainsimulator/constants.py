ROUTES = ['A-B', 'A-C', 'B-D', 'D-E', 'B-E']
